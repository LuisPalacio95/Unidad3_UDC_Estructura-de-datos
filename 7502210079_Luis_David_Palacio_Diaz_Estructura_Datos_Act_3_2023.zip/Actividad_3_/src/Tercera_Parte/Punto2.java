/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tercera_Parte;

import java.util.ArrayList;

/*
 * @author LUIS DAVID PALACIO DIAZ
 * Codigo  7502210079
 */

public class Punto2<T> {

    private ArrayList<T> cola;

    public Punto2() {
        cola = new ArrayList<>();
    }

    public void agregar(T elemento) {
        cola.add(elemento);
    }

    public T eliminar() {
        int lastIndex = cola.size() - 1;
        return cola.remove(lastIndex);
    }

    public boolean estaVacia() {
        return cola.isEmpty();
    }

    public void imprimir() {
        for (T elemento : cola) {
            System.out.println(elemento);
        }
    }

    public static void main(String[] args) {
        // Codigo para probar la cola personalizada LIFO
        Punto2<Integer> cola = new Punto2<>();

        System.out.println("Impresion de la cola personalizada LIFO \n");
        // Insertar elementos en la cola
        cola.agregar(1);
        cola.agregar(2);
        cola.agregar(3);
        cola.agregar(4);
        cola.agregar(5);
        cola.agregar(6);

        // Imprimir elementos de la cola
        cola.imprimir();

        System.out.println("");
        // Eliminar elementos de la cola
        System.out.println("Elemento eliminado: " + cola.eliminar());

        // Verificar si la cola esta vacia
        System.out.println("La cola esta vacia: " + cola.estaVacia());

        System.out.println("\nEsta es la cola despues de haber eliminado en "
                + "orden el elemento mas reciente de la cola");
        cola.imprimir();
    }
}
