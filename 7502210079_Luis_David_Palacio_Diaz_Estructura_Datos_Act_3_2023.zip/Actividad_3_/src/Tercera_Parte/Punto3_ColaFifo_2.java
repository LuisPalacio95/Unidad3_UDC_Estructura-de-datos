/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tercera_Parte;

import java.util.LinkedList;

/*
 * @author LUIS DAVID PALACIO DIAZ
 * Codigo  7502210079
 */

public class Punto3_ColaFifo_2<T> {

    private LinkedList<T> cola;

    public Punto3_ColaFifo_2() {
        cola = new LinkedList<>();
    }

    public void agregar(T elemento) {
        cola.addLast(elemento);
    }

    public T eliminar() {
        return cola.removeFirst();
    }

    public boolean estaVacia() {
        return cola.isEmpty();
    }

    public void imprimir() {
        for (T elemento : cola) {
            System.out.println(elemento);
        }
    }

    public static void main(String[] args) {
        // Código para probar la cola personalizada FIFO
        Punto3_ColaFifo<String> cola = new Punto3_ColaFifo<>();

        System.out.println("Inicializar la cola FIFO\n");

        // Al llegar al banco, los clientes forman una fila para ser atendidos.
        cola.agregar("Cliente 1");
        cola.agregar("Cliente 2");
        cola.agregar("Cliente 3");
        cola.agregar("Cliente 4");
        cola.agregar("Cliente 5");

        // De esta manera estamos indicando que los elementos se iran enviando al final de la cola
        System.out.println("Enviar a los clientes restantes al final de la fila");
        
        System.out.println("Repetir los pasos mientras haya clientes en la fila hasta finalizar\n");
        while (!cola.estaVacia()) {
            System.out.println("Obtener el primer cliente en la fila");
            String primerCliente = cola.eliminar();
            // Lógica para atender al cliente
            System.out.println("Atender al cliente: " + primerCliente);
            // Lógica para eliminar al cliente de la cola
            System.out.println("Eliminar al cliente de la cola");
            
            System.out.println();
        }

        System.out.println("Fin del proceso");
        System.out.println("La cola esta vacia: " + cola.estaVacia());
    }
}
