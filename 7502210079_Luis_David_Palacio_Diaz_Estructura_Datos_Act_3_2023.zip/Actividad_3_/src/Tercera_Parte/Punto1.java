/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tercera_Parte;

import java.util.LinkedList;

/*
 * @author LUIS DAVID PALACIO DIAZ
 * Codigo  7502210079
 */

public class Punto1<T> {

    private LinkedList<T> cola;

    public Punto1() {
        cola = new LinkedList<>();
    }

    public void agregar(T elemento) {
        cola.addLast(elemento);
    }

    public T eliminar() {
        return cola.removeFirst();
    }

    public boolean estaVacia() {
        return cola.isEmpty();
    }

    public void imprimir() {
        for (T elemento : cola) {
            System.out.println(elemento);
        }
    }

    public static void main(String[] args) {
        // Con este codigo podemos probar nuestra cola personalizada
        Punto1<Integer> cola = new Punto1<>();

        System.out.println("Impresion de la cola personalizada prioridad FIFO \n");
        // Insertar elementos en la cola
        cola.agregar(1);
        cola.agregar(2);
        cola.agregar(3);
        cola.agregar(4);
        cola.agregar(5);
        cola.agregar(6);

        // Aqui imprimimos todos los elementos de la cola
        cola.imprimir();

        //Aqui para poder dar un salto
        System.out.println("");
        
        // Con esta linea de codigo utilizamos el metodo para eliminar
        System.out.println("Elemento eliminado: " + cola.eliminar());

        // se valida si la cola se encuentra vacia
        System.out.println("La cola esta vacia: " + cola.estaVacia());

        //Aqui se muestra la cola luego de haber eliminado el elemento mas antiguo
        System.out.println("\nEsta es la cola despues de haber "
                + "eliminado en orden el elemento mas antiguo de la cola");
        cola.imprimir();
    }
}
