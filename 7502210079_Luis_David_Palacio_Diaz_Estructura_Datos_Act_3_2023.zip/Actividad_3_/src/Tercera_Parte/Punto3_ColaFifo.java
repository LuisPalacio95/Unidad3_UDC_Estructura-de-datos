/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tercera_Parte;

import java.util.LinkedList;

/*
 * @author LUIS DAVID PALACIO DIAZ
 * Codigo  7502210079
 */

public class Punto3_ColaFifo<T> {

    private LinkedList<T> cola;

    public Punto3_ColaFifo() {
        cola = new LinkedList<>();
    }

    public void agregar(T elemento) {
        cola.addLast(elemento);
    }

    public T eliminar() {
        return cola.removeFirst();
    }

    public boolean estaVacia() {
        return cola.isEmpty();
    }

    public void imprimir() {
        for (T elemento : cola) {
            System.out.println(elemento);
        }
    }

    public static void main(String[] args) {
        Punto1<String> cola = new Punto1<>();

        System.out.println("Inicializar la cola FIFO\n");

        // Agregar valores a la cola
        cola.agregar("Cliente 1");
        cola.agregar("Cliente 2");
        cola.agregar("Cliente 3");
        cola.agregar("Cliente 4");
        cola.agregar("Cliente 5");

        System.out.println("Atentiendo a clientes en la cola");
        // Logica para enviar clientes al final de la fila si llegan nuevos clientes
        System.out.println("Enviar a los clientes que llegan despues "
                + "del primero al final de la cola");
        System.out.println("Repetir los pasos mientras haya clientes "
                + "en la cola hasta finalizar\n");

        while (!cola.estaVacia()) {
            String primerCliente = cola.eliminar();
            System.out.println("Atendiendo a: " + primerCliente);
            // Logica para atender y facturar al cliente
            System.out.println("Eliminar al cliente de la cola y "
                    + "atender al siguiente");
            // Logica para eliminar al cliente de la cola            
        }

        System.out.println("\nFinalizar proceso cuando la cola este vacia");
        System.out.println("La cola esta vacia: " + cola.estaVacia());
    }
}