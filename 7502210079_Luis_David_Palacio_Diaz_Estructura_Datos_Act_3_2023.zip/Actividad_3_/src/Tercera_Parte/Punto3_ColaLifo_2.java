/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tercera_Parte;

import java.util.ArrayList;

/*
 * @author LUIS DAVID PALACIO DIAZ
 * Codigo  7502210079
 */

public class Punto3_ColaLifo_2<T> {

    private ArrayList<T> cola;

    public Punto3_ColaLifo_2() {
        cola = new ArrayList<>();
    }

    public void agregar(T elemento) {
        cola.add(elemento);
    }

    public T eliminar() {
        int lastIndex = cola.size() - 1;
        return cola.remove(lastIndex);
    }

    public boolean estaVacia() {
        return cola.isEmpty();
    }

    public void imprimir() {
        for (T elemento : cola) {
            System.out.println(elemento);
        }
    }

    public static void main(String[] args) {

        // Con este codigo podemos probar la cola personalizada LIFO
        Punto2<String> cola = new Punto2<>();

        System.out.println("Inicializar la cola LIFO\n");

        // Al llegar al banco, los clientes forman una cola para ser atendidos.
        cola.agregar("Cliente 1");
        cola.agregar("Cliente 2");
        cola.agregar("Cliente 3");
        cola.agregar("Cliente 4");
        cola.agregar("Cliente 5");
        cola.agregar("Adulto Mayor"); // Aqui podemos apreciar la llegada de un adulto mayor

        // Lógica para enviar los clientes restantes al final de la fila
        System.out.println("Atendiendo clientes en la cola");
        System.out.println("Enviar a los clientes mas reciente al inicio "
                + "de la cola (Solo si no son adultos mayores)");
        System.out.println("Repetir los pasos mientras haya clientes en "
                + "la cola hasta finalizar\n");
        while (!cola.estaVacia()) {

            String primerCliente = cola.eliminar();
            
            // Con esto pasamos a crear la logica para atender al adulto mayor
            if (primerCliente.equals("Adulto Mayor")) {
                
                System.out.println("Atender al adulto mayor con prioridad: " + primerCliente);
            } else {
                System.out.println("Atender al cliente: " + primerCliente);
            }
            System.out.println("Eliminar al cliente de la cola");         
            System.out.println();
        }

        System.out.println("Fin del proceso");
        System.out.println("La cola esta vacia: " + cola.estaVacia());
    }
}
