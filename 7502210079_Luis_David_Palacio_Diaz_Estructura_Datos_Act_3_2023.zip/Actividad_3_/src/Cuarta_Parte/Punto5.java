/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cuarta_Parte;

import java.util.ArrayList;

/*
 * @author LUIS DAVID PALACIO DIAZ
 * Codigo  7502210079
 */

public class Punto5<T> {

    private ArrayList<T> pila;

    public Punto5() {
        pila = new ArrayList<>();
    }

    public void apilar(T elemento) {
        pila.add(elemento);
    }

    public T desapilar() {
        int lastIndex = pila.size() - 1;
        return pila.remove(lastIndex);
    }

    public boolean estaVacia() {
        return pila.isEmpty();
    }

    public void imprimir() {
        for (int i = pila.size() - 1; i >= 0; i--) {
            System.out.println(pila.get(i));
        }
    }

    public static void main(String[] args) {
        // Codigo para probar la pila personalizada LIFO
        Punto5<Integer> pila = new Punto5<>();

        System.out.println("Impresion de la pila personalizada LIFO \n");
        // Apilar elementos en la pila
        pila.apilar(1);
        pila.apilar(2);
        pila.apilar(3);
        pila.apilar(4);
        pila.apilar(5);
        pila.apilar(6);

        // Imprimir elementos de la pila
        pila.imprimir();

        System.out.println("");
        // Desapilar elementos de la pila
        System.out.println("Elemento desapilado: " + pila.desapilar());

        // Verificar si la pila esta vacia
        System.out.println("La pila esta vacia: " + pila.estaVacia());

        System.out.println("\nEsta es la lista despues de haber desapilado "
                + "en orden el elemento mas reciente de la pila");
        pila.imprimir();
    }
}
