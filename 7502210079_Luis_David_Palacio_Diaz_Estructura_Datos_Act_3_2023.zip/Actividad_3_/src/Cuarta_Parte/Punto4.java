/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cuarta_Parte;

import java.util.NoSuchElementException;

/*
 * @author LUIS DAVID PALACIO DIAZ
 * Codigo  7502210079
 */

class PilaPersonalizada {

    private Nodo cima;

    public PilaPersonalizada() {
        this.cima = null;
    }

    public boolean estaVacia() {
        return cima == null;
    }

    public void apilar(int dato) {
        Nodo nuevoNodo = new Nodo(dato);
        if (estaVacia()) {
            cima = nuevoNodo;
        } else {
            nuevoNodo.siguiente = cima;
            cima = nuevoNodo;
        }
        System.out.println("Apilando: " + dato);
    }

    public int desapilar() {
        if (estaVacia()) {
            throw new NoSuchElementException("La pila esta vacia");
        }
        int dato = cima.dato;
        cima = cima.siguiente;
        System.out.println("Desapilando: " + dato);
        return dato;
    }

    public int cima() {
        if (estaVacia()) {
            throw new NoSuchElementException("La pila esta vacia");
        }
        return cima.dato;
    }

    public void vaciar() {
        cima = null;
        System.out.println("Se ha limpiado la pila y esta vacia.");
    }

    private class Nodo {

        private int dato;
        private Nodo siguiente;

        public Nodo(int dato) {
            this.dato = dato;
            this.siguiente = null;
        }
    }
}

public class Punto4 {

    public static void main(String[] args) {
        // Codigo para probar la pila personalizada
        PilaPersonalizada pila = new PilaPersonalizada();

        System.out.println("Impresion de la Pilas Apilada");
        // Apilar elementos en la pila
        pila.apilar(100);
        pila.apilar(200);
        pila.apilar(300);
        pila.apilar(400);
        pila.apilar(500);
        pila.apilar(600);

        System.out.println("\nImpresion de la Pilas Desapilada");

        // Se valida para saber si la pila esta vacia antes de obtener el valor de la cima
        if (!pila.estaVacia()) {
            // con esto podemos obtener el valor de la cima
            System.out.println("Cima de la pila: " + pila.cima());
        } else {
            System.out.println("La pila esta vacia. No se puede obtener la cima.");
        }
        while (!pila.estaVacia()) {
            System.out.println("Elemento desapilado: " + pila.desapilar());
        }
        // aqui vaciamos la pila
        pila.vaciar();
        // y aqui una vez mas valida despues de haber vaciado la pila que no quede nada 
        System.out.println("La pila esta vacia? " + pila.estaVacia());
    }
}
