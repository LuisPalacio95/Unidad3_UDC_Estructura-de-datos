/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cuarta_Parte;

import java.util.LinkedList;
import java.util.Stack;

/*
 * @author LUIS DAVID PALACIO DIAZ
 * Codigo  7502210079
 */

public class Punto6 {

    private LinkedList<String> filaCaja;

    public Punto6() {
        filaCaja = new LinkedList<>();
    }

    public void atenderCliente() {
        if (filaCaja.isEmpty()) {
            System.out.println("No hay clientes en la fila.");
        } else {
            String cliente = filaCaja.removeLast();
            System.out.println("Atendiendo al cliente: " + cliente);
        }
    }

    public void agregarCliente(String cliente) {
        filaCaja.addLast(cliente);
    }

    public void procesarCaja() {
        while (!filaCaja.isEmpty()) {
            atenderCliente();
        }
        System.out.println("No quedan clientes en la fila.");
    }

    public static void main(String[] args) {

        Stack<Integer> pila = new Stack<>();

        // aqui se agregan los elementos a la pila
        pila.push(10);
        pila.push(20);
        pila.push(30);
        pila.push(40);

        System.out.println("Pila original: " + pila);

        // se elimina el elemento que esta en la parte de arriba de la pilla
        int elementoEliminado = eliminarElemento(pila);

        System.out.println("Elemento eliminado: " + elementoEliminado);
        System.out.println("Pila despues de eliminar: " + pila);
    }

    public static int eliminarElemento(Stack<Integer> pila) {
        return pila.pop();
    }
}
